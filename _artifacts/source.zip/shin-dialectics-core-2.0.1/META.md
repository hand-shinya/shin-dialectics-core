Purpose: research record + permissive reuse + minimal runnable tools.
