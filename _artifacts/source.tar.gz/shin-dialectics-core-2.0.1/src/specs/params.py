LAMBDA_P=15
LAMBDA_A=20
LAMBDA_S=12
LAMBDA_I=30
TAU_STOP=0.66
U_MAX=0.20
AXES_DEFAULT=["Historical","Psychological","Economic","Ethical","Computational","Pedagogical","Organizational"]
STANCES_DEFAULT=5
